# V10 Balanced Gap

- Rebalanced double-line text sizes: first line slightly smaller, second line larger.
- Added user-adjustable 0.0–2.0 dp line-gap slider, default 1.0 dp.
- Preserved full-height vertical centering and -0.65 dp optical correction.
- Double-line mode clears tabular-number font features so time/date inherit the current Samsung/user-selected typeface consistently.
- Single-line behavior remains unchanged.
