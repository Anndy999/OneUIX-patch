# V9 Line Gap Fine-Tune - build notes

Goal: match the reference screenshot more closely while preserving the V8 behavior that users already confirmed was vertically centered.

Changes from V8:

- Keep all five V8 double-line clock size presets unchanged.
- Keep full-height clock view + `CENTER_VERTICAL` unchanged.
- Keep the `-0.65dp` optical upward correction unchanged.
- Add only `0.60dp` of physical extra spacing between the two text lines via `TextView.setLineSpacing(add, mult)`.
- Keep the per-preset multipliers unchanged, so the adjustment is intentionally small instead of another large re-tune.
- Keep single-line restoration behavior unchanged.
- Stable package id remains `io.github.anndy999.oneuix` so this build can update the existing modified build.
- Version: `1.7.0-anndy999-v9-linegap` (`versionCode 21`).

Preset mapping remains:

| Preset | Time | Date | Multiplier | Extra gap |
| --- | ---: | ---: | ---: | ---: |
| Small | 76% | 64% | 0.72 | +0.60dp |
| Compact | 80% | 68% | 0.69 | +0.60dp |
| Standard | 84% | 72% | 0.66 | +0.60dp |
| Large | 88% | 76% | 0.63 | +0.60dp |
| Extra large | 92% | 80% | 0.60 | +0.60dp |
